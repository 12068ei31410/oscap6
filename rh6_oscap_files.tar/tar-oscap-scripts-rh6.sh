#!/bin/bash

tar cf rh6_oscap_files.tar ./*oscap*rh6.sh ./*oscap*rh6.py
rm -f ./*.sh
rm -f ./*.py
